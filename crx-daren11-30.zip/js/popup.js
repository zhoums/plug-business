$(function(){
    /*var bg = chrome.extension.getBackgroundPage();
    bg.setBegin();*/

})